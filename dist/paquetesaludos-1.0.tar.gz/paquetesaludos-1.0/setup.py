from setuptools import setup

setup(
    name="paquetesaludos",
    version="1.0",
    description="Este es un paquete que contiene saludos",
    author="HG2905",
    url="www.henryhg2905.com",
    packages=["saludos", "saludos.despedida"]
)

print("Este programa te saluda...")

def despedida(nombre):
    print(f"Adios {nombre}")

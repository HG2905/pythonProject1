print("Este programa te saluda...")
def bienvenida (nombre ):
    print(f"Bienvenido {nombre}")

def despedida(nombre):
    print(f"Adios {nombre}")

from setuptools import setup

setup(
    name="paquetebienvenida",
    version="1.0",
    description="Este es un paquete que contiene la bienvenida",
    author="HG2905",
    url="www.henryhg2905.com",
    packages=["bienvenida"]
)

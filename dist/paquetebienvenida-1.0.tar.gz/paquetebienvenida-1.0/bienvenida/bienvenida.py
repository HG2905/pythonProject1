print("Este programa te saluda...")
def bienvenida (nombre ):
    print(f"Bienvenido {nombre}")